<?php
  session_start();
?>
<!DOCTYPE>
<html>

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
  <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">

  <nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="" href="#"><img src="image/logo.jpg" width="50px" /></a>

    </div>
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">

        <li class="active"><a href="#">Home <span class="sr-only">(current)</span></a></li>
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Categories <span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="AboutDog.php">About Dog</a></li>
            <li><a href="FindaDog.php">Find a Dog</a></li>
            <li><a href="Gallery.php">Gallery</a></li>
            <li><a href="Contacts.php">Contacts</a></li>
            
          </ul>
        </li>
      </ul>


      <ul class="nav navbar-nav navbar-right">
        <li><a href="admin/admin.php">Admin</a></li>
        <body {
        background-color: #8e181b;
        }
      </ul>
    </div>
  </div>
</nav>
</p>
</div>
</div>
</header>
<div id='minicontent1'><img id='imagestyles' src='background/logo2.png' width='400px' height='250px'><div id='share-buttons'>
    

     
    <a href='http://www.facebook.com/sharer.php?u=http://localhost/2ez/home.php' target='_blank'>
        <img src='http://localhost/2ez/icons/facebook.png' alt='Facebook' />
    </a>   
</div></div>"; 
<section id="content" class="content">
<div class="container well2">
<div class="row">
<div class="box box__skin1">
<div class="box_aside">
<div class="tm-icon01"></div>
<font size="8" color="Black">About breed</font>
</h2>
<div class="container well2">
<div class="row">
<div class="grid_4 wow fadeIn" data-wow-delay="0.2s">
<div class="box box__skin1">
<div class="box_aside">
<div class="tm-icon01"></div>
Image result for about cane corso breed
The Cane Corso is a large Italian Molosser, which is closely related to the Neapolitan Mastiff. In name and form the Cane Corso predates its cousin the Neapolitan Mastiff. It is well muscled and less bulky than most other Mastiff breeds. The breed is known as a true and quite possibly the last of the coursing Mastiffs.

Image result for about cane corso breed
The Cane Corso is a large Italian Molosser, which is closely related to the Neapolitan Mastiff. In name and form the Cane Corso predates its cousin the Neapolitan Mastiff. It is well muscled and less bulky than most other Mastiff breeds. The breed is known as a true and quite possibly the last of the coursing Mastiffs.
</div>
</div>
</div>
<div class="grid_7 wow fadeIn" data-wow-delay="0.8s">
<div class="owl-carousel">
<div class="item">
<a class="img01 thumb" style="padding-bottom: 53.51851851851852%" href="image/img01.jpg">
<img src="/image/img01.jpg" width="280" height="125" title="img01.jpg" alt="About breed"/>
<img data-src="image/img01.jpg" src="#" alt=""/>
<span class="thumb_overlay"></span>
</a>
</div>
<div class="item">
<a class="lazy-img thumb" style="padding-bottom: 53.51851851851852%" href="image/img01.jpg">
<img data-src="image/img01.jpg" src="#" alt=""/>
<span class="thumb_overlay"></span>
</a>
</div>
<div class="item">
<a class="lazy-img thumb" style="padding-bottom: 53.51851851851852%" href="image/img01.jpg">
<img data-src="image/img01.jpg" src="#" alt=""/>
<span class="thumb_overlay"></span>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="container well2">
<div class="row">
<div class="grid_4 wow fadeIn" data-wow-delay="0.2s">
<div class="box box__skin1">
<div class="box_aside">
<div class="tm-icon01"></div>
</div>
<div class="box_cnt box_cnt__no-flow">
<h3 class="default-color">
<a href="#">
<strong>
dog care &
nutrition
</strong>
</a>
</h3>
<p>
Praesent vestibulum aenean nonummy endrerit mauris. Cum sociis natoque Magnis dis
parturient montes. Ascetur ridiculus mus.Nulla dui. Fusce feugiat malesuada odio. Morbi
nunc odio gravida at cursus nec luctus a lorem.
</p>
<a class="btn" href="#">read more <span class="fa fa-angle-right"></span></a>
</div>
</div>
</div>
<div class="grid_4 wow fadeIn" data-wow-delay="0.4s">
<div class="box box__skin1">
<div class="box_aside">
<div class="tm-icon03"></div>
</div>
<div class="box_cnt box_cnt__no-flow">
<h3 class="default-color">
<a href="#">
<strong>
dog health
problems
</strong>
</a>
</h3>
<p>
Praesent vestibulum aenean nonummy endrerit mauris. Cum sociis natoque Magnis dis
parturient montes. Ascetur ridiculus mus.Nulla dui. Fusce feugiat malesuada odio. Morbi
nunc odio gravida at cursus nec luctus a lorem.
</p>
<a class="btn" href="#">read more <span class="fa fa-angle-right"></span></a>
</div>
</div>
</div>
<div class="grid_4 wow fadeIn" data-wow-delay="0.6s">
<div class="box box__skin1">
<div class="box_aside">
<div class="tm-icon05"></div>
</div>
<div class="box_cnt box_cnt__no-flow">
<h3 class="default-color">
<a href="#">
<strong>
express help
for your dog
</strong>
</a>
</h3>
<p>
Praesent vestibulum aenean nonummy endrerit mauris. Cum sociis natoque Magnis dis
parturient montes. Ascetur ridiculus mus.Nulla dui. Fusce feugiat malesuada odio. Morbi
nunc odio gravida at cursus nec luctus a lorem.
</p>
<a class="btn" href="#">read more <span class="fa fa-angle-right"></span></a>
</div>
</div>
</div>
</div>
</div>
<div class="bg-secondary">
<div class="container">
<div class="bg-image1 well3">
<div class="relative">
<h2 class="wow fadeIn" data-wow-delay="0.2s">
Tips for new <br/>
dog owners:
</h2>
<div class="row">
<div class="grid_9 preffix_2">
<ul class="index-list owl-carousel-list">
<li data-index="01" class="item wow fadeIn" data-wow-delay="0.4s">
<h6>
<a href="#">
Praesent vestibulum aenean nonummy <br/>
endrerit mauris.
</a>
</h6>
<p class="secondary-color">
Cum sociis natoque Magnis <br/>
dis parturient montes. Ascetur ridiculus mus. Nulla dui. Fusce <br/>
feugiat malesuada
odio.
Morbi <br/>
nunc odio gravida at cursus <br/>
nec luctus a lorem.
</p>
</li>
<li data-index="02" class="item wow fadeIn" data-wow-delay="0.6s">
<h6>
<a href="#">
Praesent vestibulum aenean nonummy <br/>
endrerit mauris.
</a>
</h6>
<p class="secondary-color">
Cum sociis natoque Magnis <br/>
dis parturient montes. Ascetur ridiculus mus. Nulla dui. Fusce <br/>
feugiat malesuada
odio.
Morbi <br/>
nunc odio gravida at cursus <br/>
nec luctus a lorem.
</p>
</li>
<li data-index="03" class="item wow fadeIn" data-wow-delay="0.8s">
<h6>
<a href="#">
Praesent vestibulum aenean nonummy <br/>
endrerit mauris.
</a>
</h6>
<p class="secondary-color">
Cum sociis natoque Magnis <br/>
dis parturient montes. Ascetur ridiculus mus. Nulla dui. Fusce <br/>
feugiat malesuada
odio.
Morbi <br/>
nunc odio gravida at cursus <br/>
nec luctus a lorem.
</p>
</li>
<li data-index="04" class="item">
<h6>
<a href="#">
Praesent vestibulum aenean nonummy <br/>
endrerit mauris.
</a>
</h6>
<p class="secondary-color">
Cum sociis natoque Magnis <br/>
dis parturient montes. Ascetur ridiculus mus. Nulla dui. Fusce <br/>
feugiat malesuada
odio.
Morbi <br/>
nunc odio gravida at cursus <br/>
nec luctus a lorem.
</p>
</li>
<li data-index="05" class="item">
<h6>
<a href="#">
Praesent vestibulum aenean nonummy <br/>
endrerit mauris.
</a>
</h6>
<p class="secondary-color">
Cum sociis natoque Magnis <br/>
dis parturient montes. Ascetur ridiculus mus. Nulla dui. Fusce <br/>
feugiat malesuada
odio.
Morbi <br/>
nunc odio gravida at cursus <br/>
nec luctus a lorem.
</p>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="bg-secondary2 well4"></div>
</section>
  <style type="text/css">
    #homecontent{
  background: url("background/home2.jpg");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  background-color: gray;

}
body{
  background: url("background/home2.jpg");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  background-color: gray;
}
h1{

    color: white;
    font-family: helvetica;

}
  </style>
  
   </head>
  <body>
  
  <?php
   

    include("config/config.php");
    require_once("nbbc/nbbc.php");
    $bbcode = new bbcode;

    $sql = "SELECT * FROM posts ORDER BY id DESC";
    $res = mysqli_query($conn,$sql) or die(mysqli_error());

    $posts = "";

    if(mysqli_num_rows($res)>0){
      while($row = mysqli_fetch_assoc($res)){
        $id = $row['id'];
        $title = $row['title'];
        $content = $row['content'];
        $date = $row['date'];
        $image = $row['image'];
        $output = $bbcode->Parse($content);

        echo "<div id='homecontent'>";
        $posts .= "<div id='content1'><h2 id=h1style>$title</h2><p id='outputstyle'>$output</p><img id='imagestyle' src='image/".$image."' width='400px' height='200px'><p id='datestyle'>Published: $date</p></div>";


      }
      echo $posts;
    } else {
      echo "There are no posts to display!";
    }
   
    
  ?>
  
    
</body>
</html>