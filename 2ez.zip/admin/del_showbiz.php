<?php
	session_start();
?>
<?php
	include("../config/config.php");

	if(!isset($_GET['pid'])){
		header("Location: login.php");
	}else{
		$pid = $_GET['pid'];
		$sql = "DELETE FROM showbiz WHERE id=$pid";
		mysqli_query($conn, $sql);
		header("Location: admin_showbiz.php");
	}
?>