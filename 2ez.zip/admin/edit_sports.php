<?php
	session_start();

?>
<?php	
	include_once("../config/config.php");

	
	if(!isset($_GET['pid'])){
		header("Location: login.php");
	}

	$pid = $_GET['pid'];

	if(isset($_POST['update'])){
		$title = strip_tags($_POST['title']);
		$content = strip_tags($_POST['content']);
		
		$title = mysqli_real_escape_string($conn, $title);
		$content = mysqli_real_escape_string($conn, $content);

		$date = date('l js \of F Y h:i:s A');

		$sql = "UPDATE sports SET title='$title', content='$content', date='$date' WHERE id=$pid";

		if($title == "" || $content == ""){
			echo "Please Complete your post!";
			return;
		}
		mysqli_query($conn,$sql);

		header("Location: http://localhost/kaya_yan/admin/admin_sports.php");
	}
?>
<!DOCTYPE>
<html>
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
   <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
  <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">

  <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="" href="#"><img src="../image/logo2.png" width="88px" /></a>

    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        
        <li class="active"><a href="admin_sports.php">Back <span class="sr-only">(current)</span></a></li>
        
        
      </ul>

     
    </div>
  </div>
</nav>
</head>
<body>
	<?php
		$sql_get = "SELECT * FROM sports WHERE id=$pid LIMIT 1";
		$res = mysqli_query($conn, $sql_get);

		if(mysqli_num_rows($res)>0){
			while($row = mysqli_fetch_assoc($res)){
				$title = $row['title'];
				$content = $row['content'];

				echo "<form action='edit_sports.php?pid=$pid' method='post' enctype='multipart/form-data'>";
				echo "<center><div id='postdesign'><input placeholder='Title' name='title' type='text' value='$title' autofocus size='48'><br/></br>";
				echo "<textarea placeholder='content' name='content' rows='20' cols='50'>$content</textarea></br>";
			}
		}
	?>

	<br><input class="button" name="update" type="submit" value="Update">
	</div>
	</center>
</form>
</body>
</html>