<?php
  session_start();

  if(!isset($_SESSION['admin']) && $_SESSION['admin'] !=1){
      header("Location: login.php");
      return;
  }
?>
<!DOCTYPE>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
  <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">

  <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="" href="#"><img src="../image/logo2.png" width="88px" /></a>

    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="http://localhost/kaya_yan/admin/admin.php">Home <span class="sr-only">(current)</span></a></li>
        
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Categories <span class="caret"></span></a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="admin_sports.php">Sports</a></li>
            <li><a href="admin_money.php">Money</a></li>
            <li><a href="admin_showbiz.php">Showbiz</a></li>
           
            
          </ul>
        </li>
      </ul>
       
      <ul class="nav navbar-nav navbar-right">
        <li><a href="logout.php">Logout</a></li>
      </ul>
      
    </div>
  </div>
</nav>

  <style type="text/css">
    #homecontent{
  background: url("../background/admin.jpg");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  background-color: gray;

}
body{
  background: url("../background/admin.jpg");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  background-color: gray;
}
h1{

    color: white;
    font-family: helvetica;

}
  </style>

   </head>
  <body>
  <?php
    echo "<h1>Latest News</h1>";
    echo "<center><a href='post.php' class='button'>Post</a></center>";
    include("../config/config.php");
    echo "<div id='content'>";
    
    $sql = "SELECT * FROM posts ORDER BY id DESC";
    $res = mysqli_query($conn,$sql) or die(mysqli_error());

    $posts = "";

    if(mysqli_num_rows($res)>0){
      while($row = mysqli_fetch_assoc($res)){
        $id = $row['id'];
        $title = $row['title'];
        $content = $row['content'];
        $date = $row['date'];
        $image = $row['image'];

       
        $admin = "<center><div><a href='del_post.php?pid=$id'>Delete |</a>&nbsp;<a href='edit_post.php?pid=$id'>Edit</a></div></center>";

        $posts .= "<center><div id='content1'><h2 id=h1style>$title</h2><p id='outputstyle'>$content</p><img id='imagestyle' src='../image/".$image."' width='400px' height='200px'><p id='datestyle'>Published: $date</p></h3><h3>$admin</h3></div></center>";
      }
      echo $posts;
              
    } else {
      echo "<br>There are no posts to display!</div>";
    }

  ?>
 </body>

</html>