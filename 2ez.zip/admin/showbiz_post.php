<?php
	session_start();

	  if(!isset($_SESSION['admin']) && $_SESSION['admin'] !=1){
      header("Location: login.php");
      return;
  }
?>
<?php	
	include_once("../config/config.php");

	if(isset($_POST['post'])){
		$title = strip_tags($_POST['title']);
		$content = strip_tags($_POST['content']);
		
		$title = mysqli_real_escape_string($conn, $title);
		$content = mysqli_real_escape_string($conn, $content);

		$date = date("F j, Y, g:i a");

		$image_name = $_FILES['image']['name'];
        $image_name = mt_rand(100000, 999999).$image_name;
        $image_name_tmp =  $_FILES['image']['tmp_name'];
        $image_type = $_FILES['image']['type'];
        $image_size = $_FILES['image']['size'];

        $image_name = preg_replace("#[^a-z0-9.]#i", "", $image_name);

        move_uploaded_file($image_name_tmp, "../image/$image_name");

		$sql = "INSERT into showbiz (title, content, date, image) VALUES ('$title', '$content','$date','$image_name')";

		if($title == "" || $content == ""){
			echo "Please Complete your post!";
			return;
		}
		mysqli_query($conn,$sql);

		header("Location: http://localhost/kaya_yan/admin/admin_showbiz.php");
	}
?>
<!DOCTYPE>
<html>
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
  <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">

  <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="" href="#"><img src="../image/logo2.png" width="88px" /></a>

    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
      
      <li class="active"><a href="admin_showbiz.php">Back <span class="sr-only">(current)</span></a></li>
        
               
      </ul>

      
    </div>
  </div>
</nav>

  
  
</head>
<body>
<form action="showbiz_post.php" method="post" enctype="multipart/form-data">
	<center>
  <div id="postdesign" >
  <input placeholder="Title" name="title" type="text" autofocus size="48" required><br/></br>
  <textarea placeholder="content" name="content" rows="20" cols="50" required></textarea></br>
  <input type="file" name="image" required><br>
  <input name="post" class="button" type="submit" value="Post"><br>
  </div>
  </center>
</form>
</body>
</html>