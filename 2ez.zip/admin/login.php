<?php
    session_start();
?>
 <!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body link="blue">

<form method = "post" action="#">
<center>
<div>
<h1>Admin</h1>
<input type="text" name="username" placeholder="Username" required id="logins"><br/>
<input type="password" name="password" placeholder="Password" required id="logins"><br/>
<input type="submit" name="login" value="Log In"><br/>
<a href="http://localhost/kaya_yan/home.php" id="back">Back</a>



</form>
<?php


   if(isset($_POST['login'])){

        include("../config/config.php");
            $username = $_POST['username'];
            $password = $_POST['password'];

        $myusername = stripslashes($username);
        $mypassword = stripslashes($password);
        $myusername = mysqli_real_escape_string($conn, $myusername);
        $mypassword = mysqli_real_escape_string($conn, $mypassword);
    $sql ="SELECT * FROM admin_accounts WHERE username='$myusername' AND password='$mypassword'";

       $query = mysqli_query($conn, $sql);
       $row = mysqli_num_rows($query);
       $id = $row['id'];
       $admin = $row['admin'];
       if($row>0){
             $_SESSION['admin'] = $username;
             $_SESSION['id'] = $id;
             if($admin == 1){
                $_SESSION['admin'] = 1;
             }
        
                    header('Location: admin.php');
                
                    
        }else{
            echo "<font color='white'>Invalid Username/password</font>";

        }
    }
?>
</div>
</center>
</body>
<style type="text/css">
 body{
        background: url("../background/login.jpeg");
        background-repeat: no-repeat;
        background-size: cover;
        background-color: gray;
    }
a{
    color: #5F5F5F;
    text-decoration:none
}
h1{
    color: #2B2B2B;
    font-family: helvetica;
}

::-webkit-input-placeholder{  
   color:  white;                         /*placeholder*/
   opacity: 1;
}
    input[type=text], select , input[type=password],select{
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    box-sizing: border-box;
    background-color: #5F5F5F;
    color: white;
    border:2px solid #456879;
    border-radius:10px;
    height: 35px;
    opacity: 1;
}

input[type=submit] {
    width: 100%;
    background-color: #188E42;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

input[type=submit]:hover {
    background-color: #31AB5C;
}
div {
    
    border-radius: 5px;
    background-color: white;
    padding: 20px;
    width: 300px;
    height: 250px;
    margin-top: 80px;
    opacity: 0.8;

}
#genders{
     color: #a6a6a6;
}
#already{
    color: #BBBBBB;
}


</style>
</html>