
<font size="5" color="Black">CALL ME:</font>
<font size="5" color="Black">0936 926 5002</font>
<div>        
        <br style="clear:both">
            <div class="form-group col-md-4 ">                                
                <label id="messageLabel" for="message">Message </label>
                <textarea class="form-control input-sm " type="textarea" id="message" placeholder="Message:" maxlength="300" rows="7"></textarea>
                    <span class="help-block"><p id="characterLeft" class="help-block "></p></span>                    
            </div>
        
        <br style="clear:both">
        <div class="form-group col-md-2">
        <button class="form-control input-sm btn btn-success disabled" id="btnSubmit" name="btnSubmit" type="button" style="height:40px"> Send</button>    
    </div>
</div>

  <style type="text/css">
    #homecontent{
  background: url("background/mail.jpg");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  background-color: gray;

}
body{
  background: url("background/mail.jpg");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  background-color: gray;
}
h1{

    color: white;
    font-family: helvetica;

}
  </style>