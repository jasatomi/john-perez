<head>
<title>Home</title>
</head>
<body>
<div class="page bg-primary">
<header id="header" class="header">
<div class="container">
<div class="row">
<div class="grid_5 preffix_7">
</div>
</div>
</div>
<div class="row">
<div class="grid_10 preffix_2">
<nav class="nav">
<ul class="sf-menu">
<li class="active">
<a href="./">Home</a>
</li>
<li>
<a href="index-1.html">About dog</a>
<ul>
<li>
<a href="index-2.html">Find a dog</a>
</li>
<li>
<a href="index-3.html">Gallery</a>
</li>
<li>
<a href="index-4.html">Contact me</a>
</li>
</ul>
</nav>
</div>
</div>
<font size="5" color="Black">Call Me</font>
<div class="phone">
<span>0936 926 5002</span>
<div class="brand">
<h1 class="brand_name">
</p>
</div>
</div>
</header>
<section id="content" class="content">
<div class="well">
<div class="container relative">
<h2 class="wow fadeIn" data-wow-delay="0.2s">
About breed
</h2>
<div class="row">
<div class="grid_4 preffix_1">
</h2>
<div class="row">
<div class="grid_4 preffix_1">
<p class="wow fadeIn" data-wow-delay="0.4s">
The Cane Corso is a large Italian Molosser, which is closely related to the Neapolitan Mastiff. In name and form the Cane Corso predates its cousin the Neapolitan Mastiff. It is well muscled and less bulky than most other Mastiff breeds. The breed is known as a true and quite possibly the last of the coursing Mastiffs.
</p>
<div class="row">
<div class="grid_3 preffix_1">
<p class="secondary-color wow fadeIn" data-wow-delay="0.6s">
</p>
</div>
</div>
</div>
<div class="grid_7 wow fadeIn" data-wow-delay="0.8s">
<div class="owl-carousel">
<div class="item">
<a class="page-1_img02" style="padding-bottom: 53.51851851851852%" href="page-1_img02">
<img data-src="images/page-1_img01.jpg" src="#" alt=""/>
<span class="thumb_overlay"></span>
</a>
</div>
<div class="item">
<a class="page-1_img02" style="padding-bottom: 53.51851851851852%" href="images/page-1_img02.jpg">
<img data-src="images/page-1_img02.jpg" src="#" alt=""/>
<span class="thumb_overlay"></span>
</a>
</div>
<div class="item">
<a class="page-1_img02" style="padding-bottom: 53.51851851851852%" href="page-1_img02">
<img data-src="page-1_img02" src="#" alt=""/>
<span class="thumb_overlay"></span>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="container well2">
<div class="row">
<div class="grid_4 wow fadeIn" data-wow-delay="0.2s">
<div class="box box__skin1">
<div class="box_aside">
<div class="tm-icon01"></div>
</div>
<head>
<title>Home</title>
</head>
<body>
<div class="page bg-primary">
<header id="header" class="header">
<div class="container">
<div class="row">
<div class="grid_5 preffix_7">
</div>
</div>
</div>
<div class="row">
<div class="grid_10 preffix_2">
<nav class="nav">
<ul class="sf-menu">
<li class="active">
<a href="./">Home</a>
</li>
<li>
<a href="index-1.html">About dog</a>
<ul>
<li>
<a href="index-2.html">Find a dog</a>
</li>
<li>
<a href="index-3.html">Gallery</a>
</li>
<li>
<a href="index-4.html">Contact me</a>
</li>
</ul>
</nav>
</div>
</div>
<div class="brand">
<h1 class="brand_name">
<a href="./">Dog</a>
</h1>
<p class="brand_slogan">
Cane corso <br/>
breeder
</p>
</div>
</div>
</header>
<section id="content" class="content">
<div class="well">
<div class="container relative">
<h2 class="wow fadeIn" data-wow-delay="0.2s">
About breed
</h2>
<div class="row">
<div class="grid_4 preffix_1">
</h2>
<div class="row">
<div class="grid_4 preffix_1">
<p class="wow fadeIn" data-wow-delay="0.4s">
The Cane Corso is a large Italian Molosser, which is closely related to the Neapolitan Mastiff. In name and form the Cane Corso predates its cousin the Neapolitan Mastiff. It is well muscled and less bulky than most other Mastiff breeds. The breed is known as a true and quite possibly the last of the coursing Mastiffs.
</p>
<div class="row">
<div class="grid_3 preffix_1">
<p class="secondary-color wow fadeIn" data-wow-delay="0.6s">
</p>
</div>
</div>
</div>
<div class="grid_7 wow fadeIn" data-wow-delay="0.8s">
<div class="owl-carousel">
<div class="item">
<a class="page-1_img02" style="padding-bottom: 53.51851851851852%" href="page-1_img02">
<img data-src="images/page-1_img01.jpg" src="#" alt=""/>
<span class="thumb_overlay"></span>
</a>
</div>
<div class="item">
<a class="page-1_img02" style="padding-bottom: 53.51851851851852%" href="images/page-1_img02.jpg">
<img data-src="images/page-1_img02.jpg" src="#" alt=""/>
<span class="thumb_overlay"></span>
</a>
</div>
<div class="item">
<a class="page-1_img02" style="padding-bottom: 53.51851851851852%" href="page-1_img02">
<img data-src="page-1_img02" src="#" alt=""/>
<span class="thumb_overlay"></span>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="container well2">
<div class="row">
<div class="grid_4 wow fadeIn" data-wow-delay="0.2s">
<div class="box box__skin1">
<div class="box_aside">
<div class="tm-icon01"></div>
</div>
<div class="box_cnt box_cnt__no-flow">
<h3 class="default-color">
<a href="#">
<strong>
DOG CARE &
NUTRITION
</strong>
</a>
</h3>
<p>
A balanced diet is critically important to your dog’s cell maintenance and growth and overall health. Barring any special needs, illness-related deficiencies, or instructions from your vet, your pet should be able to get all the nutrients he or she needs from high-quality commercial pet foods, which are specially formulated with these standards in mind.
</p>
<a class="btn" href="#">read more <span class="fa fa-angle-right"></span></a>
</div>
</div>
</div>
<div class="grid_4 wow fadeIn" data-wow-delay="0.4s">
<div class="box box__skin1">
<div class="box_aside">
<div class="tm-icon03"></div>
</div>
<div class="box_cnt box_cnt__no-flow">
<h3 class="default-color">
<a href="#">
<strong>
DOG HEALTH
PROBLEMS
</strong>
</a>
</h3>
<p>
lways take your dog to the veterinarian if you think he has an ear infection. In most cases, cleaning and medicating the ear canal will quickly clear up an infection. However, surgery can be needed for chronic infections or if forceful head shaking results in the rupture of a vessel within the outer part of the ear.
</p>
<a class="btn" href="#">read more <span class="fa fa-angle-right"></span></a>
</div>
</div>
</div>
<div class="grid_4 wow fadeIn" data-wow-delay="0.6s">
<div class="box box__skin1">
<div class="box_aside">
<div class="tm-icon05"></div>
</div>
<div class="box_cnt box_cnt__no-flow">
<h3 class="default-color">
<a href="#">
<strong>
EXPRESS HELP
FOR YOUR DOG
</strong>
</a>
</h3>
 Set up a large box outside pet supply stores and ask for donations of gently used pet items such as bedding, dog toys, etc.
 </p>
<a class="btn" href="#">read more <span class="fa fa-angle-right"></span></a>
</div>
</div>
</div>
</div>
</div>
<div class="bg-secondary">
<div class="container">
<div class="bg-image1 well3">
<div class="relative">
<h2 class="wow fadeIn" data-wow-delay="0.2s">
Tips for new <br/>
dog owners:
</h2>
<div class="row">
<div class="grid_9 preffix_9">
<ul class="index-list owl-carousel-list">
<li data-index="01" class="item wow fadeIn" data-wow-delay="0.4s">
<h6>
<a href="#">
Determine where your dog will be spending most of his time. Because he will be under a lot of stress with the change of environment (from shelter or foster home to your house), he may forget any housebreaking (if any) he’s learned. Often a kitchen will work best for easy clean-up.
</h2>
<div class="row">
<div class="grid_9 preffix_2">
<ul class="index-list owl-carousel-list">
<li data-index="01" class="item wow fadeIn" data-wow-delay="0.4s">
<h6>
<a href="#">
If you plan on crate training your dog, be sure to have a crate set-up and ready to go for when you bring your new dog home. Find out more about crate training your dog.
</p>
</li>
<li data-index="02" class="item wow fadeIn" data-wow-delay="0.6s">
<h6>
<a href="#">
Training your dog will start the first moment you have him. Take time to create a vocabulary list everyone will use when giving your dog directions. This will help prevent confusion and help your dog learn his commands more quickly.
<style type="text/css">
    #homecontent{
  background: url("background/home2.jpg");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  background-color: gray;

}
body{
  background: url("background/home2.jpg");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
  background-color: gray;
}
h1{

    color: white;
    font-family: helvetica;
